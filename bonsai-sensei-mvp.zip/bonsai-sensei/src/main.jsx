import React, { useMemo, useState } from 'react'
import { createRoot } from 'react-dom/client'
import { Camera, CalendarDays, Leaf, Search, ShieldCheck, Sun, Droplets, Wind, GraduationCap, Crown } from 'lucide-react'
import './styles.css'

const species = [
  {
    name: 'Juniper Bonsai',
    level: 'White Belt',
    type: 'Outdoor evergreen',
    sunlight: 'Full sun, 6+ hours',
    watering: 'Water when top soil begins to dry',
    health: 'Yellowing often means too much water or not enough sun.',
    photo: 'https://images.unsplash.com/photo-1501004318641-b39e6451bec6?q=80&w=1200&auto=format&fit=crop'
  },
  {
    name: 'Bald Cypress',
    level: 'Green Belt',
    type: 'Outdoor deciduous conifer',
    sunlight: 'Full sun',
    watering: 'Enjoys consistently moist soil',
    health: 'Excellent for humid Gulf Coast climates and wet conditions.',
    photo: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?q=80&w=1200&auto=format&fit=crop'
  },
  {
    name: 'Bougainvillea',
    level: 'Blue Belt',
    type: 'Tropical flowering bonsai',
    sunlight: 'Direct sun',
    watering: 'Let soil dry slightly between watering',
    health: 'Needs warmth and protection from cold snaps.',
    photo: 'https://images.unsplash.com/photo-1493246507139-91e8fad9978e?q=80&w=1200&auto=format&fit=crop'
  },
  {
    name: 'Japanese Maple',
    level: 'Brown Belt',
    type: 'Outdoor deciduous broadleaf',
    sunlight: 'Morning sun, afternoon shade',
    watering: 'Keep evenly moist, never soggy',
    health: 'Protect leaves from heat scorch and drying wind.',
    photo: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?q=80&w=1200&auto=format&fit=crop'
  },
  {
    name: 'Ficus',
    level: 'White Belt',
    type: 'Indoor tropical',
    sunlight: 'Bright indirect light',
    watering: 'Water when upper soil is dry',
    health: 'Great beginner indoor bonsai; avoid cold drafts.',
    photo: 'https://images.unsplash.com/photo-1463320726281-696a485928c7?q=80&w=1200&auto=format&fit=crop'
  },
  {
    name: 'Azalea',
    level: 'Blue Belt',
    type: 'Flowering broadleaf',
    sunlight: 'Filtered sun',
    watering: 'Keep moist with acidic soil',
    health: 'Watch for dry roots and flower stress after blooming.',
    photo: 'https://images.unsplash.com/photo-1523348837708-15d4a09cfac2?q=80&w=1200&auto=format&fit=crop'
  }
]

const dojoLessons = [
  { icon: <Droplets />, title: 'Watering Ritual', text: 'Learn how to water by soil feel, pot weight, weather, and species type.' },
  { icon: <Sun />, title: 'Light Discipline', text: 'Match each tree to the right sunlight so it grows strong instead of weak.' },
  { icon: <Leaf />, title: 'Health Sense', text: 'Spot yellow leaves, pests, fungus, root rot, and heat stress early.' },
  { icon: <Wind />, title: 'Wiring Forms', text: 'Train branches safely with beginner wiring rules and timing.' },
  { icon: <CalendarDays />, title: 'Seasonal Scrolls', text: 'Know when to prune, repot, fertilize, protect, and let the tree rest.' },
  { icon: <GraduationCap />, title: 'Belt Progression', text: 'Move from White Belt basics to Black Belt refinement.' }
]

function App() {
  const [query, setQuery] = useState('')
  const filtered = useMemo(() => {
    return species.filter(tree =>
      tree.name.toLowerCase().includes(query.toLowerCase()) ||
      tree.type.toLowerCase().includes(query.toLowerCase()) ||
      tree.level.toLowerCase().includes(query.toLowerCase())
    )
  }, [query])

  return (
    <main className="app">
      <nav className="nav">
        <div className="brandMark">盆</div>
        <div>
          <h1>Bonsai Sensei</h1>
          <p>Digital Bonsai Dojo</p>
        </div>
        <a className="premium" href="#pricing">Enter Premium Dojo</a>
      </nav>

      <section className="hero">
        <div className="heroText">
          <span className="tag">⛩️ Beginner Bonsai Training Dojo</span>
          <h2>Train Your Tree. <strong>Master the Art.</strong></h2>
          <p>
            Bonsai Sensei helps beginners identify bonsai types, understand watering,
            diagnose health problems, follow seasonal care, and learn styling through
            a Japanese dojo-inspired training path.
          </p>
          <div className="heroActions">
            <a href="#library" className="primary">Begin Training</a>
            <a href="#doctor" className="secondary">Ask the Sensei</a>
          </div>
        </div>

        <div className="doctorCard" id="doctor">
          <div className="doctorHeader">
            <h3>Sensei Tree Diagnosis</h3>
            <span>AI-ready</span>
          </div>
          <div className="uploadBox">
            <Camera size={56} />
            <h4>Present Your Bonsai</h4>
            <p>Upload a tree photo to check for pests, watering issues, disease, weak growth, and styling opportunities.</p>
            <button>Analyze Tree</button>
          </div>
          <div className="miniGrid">
            <div><b>Dojo</b><span>Guided levels</span></div>
            <div><b>24/7</b><span>Health watch</span></div>
          </div>
        </div>
      </section>

      <section className="library" id="library">
        <div className="sectionHeader">
          <div>
            <h2>Species Scroll Library</h2>
            <p>Care guides organized by beginner training level.</p>
          </div>
          <label className="search">
            <Search size={18} />
            <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search scrolls..." />
          </label>
        </div>

        <div className="cards">
          {filtered.map(tree => (
            <article className="card" key={tree.name}>
              <img src={tree.photo} alt={tree.name} />
              <div className="cardBody">
                <span className="level">{tree.level}</span>
                <h3>{tree.name}</h3>
                <p className="type">{tree.type}</p>
                <p><b>Sun Discipline:</b> {tree.sunlight}</p>
                <p><b>Water Ritual:</b> {tree.watering}</p>
                <p><b>Sensei Tip:</b> {tree.health}</p>
                <button>Study This Scroll</button>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="training">
        <h2>Dojo Training System</h2>
        <p className="center">A martial-arts-inspired training path that teaches bonsai one level at a time.</p>
        <div className="lessonGrid">
          {dojoLessons.map(lesson => (
            <div className="lesson" key={lesson.title}>
              {lesson.icon}
              <h3>{lesson.title}</h3>
              <p>{lesson.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="southern">
        <div>
          <h2>Southern Bonsai Dojo Mode</h2>
          <p>
            Built for Gulf Coast growers dealing with humidity, heat, storms,
            fungus pressure, salt air, and long growing seasons.
          </p>
          <ul>
            <li>Heat stress alerts</li>
            <li>Humidity-based watering guidance</li>
            <li>Storm and hurricane prep scrolls</li>
            <li>Fungus prevention rituals</li>
          </ul>
        </div>
        <div className="statGrid">
          <div><b>250+</b><span>Training Scrolls</span></div>
          <div><b>AI</b><span>Sensei Diagnosis</span></div>
          <div><b>Live</b><span>Weather Wisdom</span></div>
          <div><b>Zen</b><span>Guided Practice</span></div>
        </div>
      </section>

      <section className="pricing" id="pricing">
        <h2>Premium Dojo Pricing</h2>
        <div className="priceCards">
          <div className="priceCard">
            <ShieldCheck />
            <h3>Free Student</h3>
            <p>$0</p>
            <span>Species guides, basic care tips, and beginner lessons.</span>
          </div>
          <div className="priceCard featured">
            <Crown />
            <h3>Premium Dojo</h3>
            <p>$4.99/mo</p>
            <span>AI diagnosis, reminders, advanced scrolls, weather wisdom, and personal tree journal.</span>
          </div>
        </div>
      </section>

      <footer>
        <div className="brandMark small">盆</div>
        <h3>Bonsai Sensei</h3>
        <p>Digital Bonsai Dojo • AI Tree Diagnosis • Beginner Training Scrolls</p>
      </footer>
    </main>
  )
}

createRoot(document.getElementById('root')).render(<App />)
